package com.plcoding.meditationuiyoutube.ui.theme

import androidx.compose.ui.graphics.Color

val TextWhite = Color(0xFF0F0303)
val DeepBlue = Color(0xFFDDEEF5)
val ButtonBlue = Color(0xFF70B6B9)
val DarkerButtonBlue = Color(0xFF29787C)
val LightRed = Color(0xFFE26575)
val AquaBlue = Color(0xFF9CBEC0)
val OrangeYellow1 = Color(0xFFE7D39A)
val OrangeYellow2 = Color(0xFFE7D39A)
val OrangeYellow3 = Color(0xFFE7D39A)
val Beige1 = Color(0xFFEEA6D1)
val Beige2 = Color(0xFFEEA6D1)
val Beige3 = Color(0xFFEEA6D1)
val LightGreen1 = Color(0xFFB4CF88)
val LightGreen2 = Color(0xFFB4CF88)
val LightGreen3 = Color(0xFFB4CF88)
val BlueViolet1 = Color(0xFFBCA9CE)
val BlueViolet2 = Color(0xFFBCA9CE)
val BlueViolet3 = Color(0xFFBCA9CE)
